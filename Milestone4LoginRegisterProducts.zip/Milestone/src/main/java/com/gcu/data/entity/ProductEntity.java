package com.gcu.data.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table("ORDERS")
public class ProductEntity
{
	
	@Column("PRODUCT_NAME")
	String productName;
	
	@Column("DESC")
	String desc;
	
	@Column("STOCK")
	int stock;

	@Column("PRICE")
	float price;
	
	public ProductEntity()
	{
		productName = "Default Name";
		desc = "Default Description";
		stock = 0;
		price = 0F;
	}
	
	public ProductEntity(String desc, String productName, int stock, float price)
	{
		this.productName = productName;
		this.desc = desc;
		this.stock = stock;
		this.price = price;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getStock() {
		return stock;
	}

	public void getStock(int stock) {
		this.stock = stock;
	}
}
