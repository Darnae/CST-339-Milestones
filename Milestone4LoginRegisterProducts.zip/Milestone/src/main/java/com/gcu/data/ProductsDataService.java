package com.gcu.data;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.gcu.data.entity.ProductEntity;
import com.gcu.data.repository.ProductsRepository;

@Service
public class ProductsDataService implements DataAccessInterface<ProductEntity>
{
	@Autowired
	private ProductsRepository ordersRepository;
	@SuppressWarnings("unused")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	/**
	 * Non-default constructor for constructor injection.
	 */
	public ProductsDataService(ProductsRepository ordersRepository, DataSource dataSource)
	{
		this.ordersRepository = ordersRepository;
		this.dataSource = dataSource;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<ProductEntity> findAll()
	{
		List<ProductEntity> products = new ArrayList<ProductEntity>();
		
		try
		{
			// Get all the Entity Orders
			Iterable<ProductEntity> productsIterable = ordersRepository.findAll();
			
			// Convert to a List and return the List
			products = new ArrayList<ProductEntity>();
			productsIterable.forEach(products::add);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		// Return the List
		return products;
	}

	@Override
	public ProductEntity findById(int id)
	{
		return null;
	}

	@Override
	public boolean create(ProductEntity order)
	{
		// Example of "overriding" the CrusRepository save() because it simply is never called
		// You can inject a dataSource and use the jdbcTemplate to provide a customized implementation of a save() method
		String sql = "INSERT INTO PRODUCTS(PRODUCT_NAME, DESC, STOCK, PRICE) VALUES(?, ?, ?, ?)";
		try
		{
			// Execute SQL Insert
			jdbcTemplateObject.update(sql,
					order.getProductName(),
					order.getDesc(),
					order.getStock(),
					order.getPrice());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public boolean update(ProductEntity order)
	{
		return false;
	}

	@Override
	public boolean delete(ProductEntity order)
	{
		return false;
	}
}
