package com.gcu.data.entity;

public class UserEntity {

}
