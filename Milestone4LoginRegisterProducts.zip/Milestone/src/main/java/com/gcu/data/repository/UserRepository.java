package com.gcu.data.repository;

public class UserRepository {

}
