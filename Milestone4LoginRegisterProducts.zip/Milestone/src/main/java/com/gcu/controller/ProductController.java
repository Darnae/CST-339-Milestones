package com.gcu.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gcu.business.ProductBusinessInterface;
import com.gcu.model.ProductModel;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/product")
public class ProductController
{
	@Autowired
	private ProductBusinessInterface service;
	
	List<ProductModel> productList = new ArrayList<ProductModel>();
	
	@GetMapping("/")
	public String display(Model model)
	{
		model.addAttribute("title", "Products Form");
		model.addAttribute("productModel", new ProductModel());
		return "productcreation";
	}
	
	@PostMapping("/createProduct")
	public String createProduct(@Valid ProductModel productModel, BindingResult bindingResult, Model model)
	{
		// Check for validation errors
		if (bindingResult.hasErrors())
		{
			model.addAttribute("title", "Products Form");
			return "productcreation";
		}
		
		productList.add(productModel);
		
		// Reload to the Product Creation Menu
		return "productcreation";
	}
	
	@PostMapping("/viewProduct")
	public String viewProduct(@Valid ProductModel productModel, BindingResult bindingResult, Model model)
	{
		// Check for validation errors
		if (bindingResult.hasErrors())
		{
			model.addAttribute("title", "Product View");
			return "productcreation";
		}
		
		// View the products
		List<ProductModel> products = service.getProducts();
		// Add on the created products
		products.addAll(productList);
				
		model.addAttribute("title", "My Products");
		model.addAttribute("products", products);

		// Navigate to the Post Creation View
		return "postcreation";
	}
}
