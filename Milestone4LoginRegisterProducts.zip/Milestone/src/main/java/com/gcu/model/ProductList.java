package com.gcu.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="orders")
public class ProductList
{
	private List<ProductModel> products = new ArrayList<ProductModel>();
	
		@XmlElement(name="products")
		public List<ProductModel> getProducts()
		{
			return this.products;
		}
	
		public void setOrders(List<ProductModel> products)
		{
			this.products = products;
		}
}
