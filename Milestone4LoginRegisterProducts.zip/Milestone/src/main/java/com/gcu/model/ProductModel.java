package com.gcu.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ProductModel 
{
	@NotNull(message="Product name is a required field")
	@Size(min=1, max=32, message="Product name must be between 1 and 32 characters")
	private String name;
	@NotNull(message="Description is a required field")
	@Size(min=1, message="Description must be at least 1 character")
	private String desc;
	@NotNull(message="Stock is a required field")
	private int stock;
	@NotNull(message="Price is a required field")
	private float price;
	
	public ProductModel(String name, String desc, int stock, float price)
	{
		this.name = name;
		this.desc = desc;
		this.stock = stock;
		this.price = price;
	}
	
	public ProductModel()
	{
		this.name = "default product";
		this.desc = "default description";
		this.stock = 1;
		this.price = 1F;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	
}
