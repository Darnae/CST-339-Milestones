package com.gcu.model;

import java.util.ArrayList;

public class DatabaseModel
{
	private ArrayList<LoginModel> loginDatabase;
	
	public DatabaseModel(ArrayList<LoginModel> loginDatabase, LoginModel loginModel)
	{
		this.loginDatabase = loginDatabase;
		this.loginDatabase.add(loginModel);
	}

	public ArrayList<LoginModel> getLoginDatabase()
	{
		return loginDatabase;
	}

	public void setLoginDatabase(ArrayList<LoginModel> loginDatabase)
	{
		this.loginDatabase = loginDatabase;
	}
	
	
}
