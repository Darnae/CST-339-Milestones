package com.gcu;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.gcu.business.ProductBusinessInterface;
import com.gcu.business.ProductBusinessService;
import com.gcu.business.RegistrationService;
import com.gcu.business.RegistrationServiceInterface;

@Configuration
public class SpringConfig 
{
	@Bean(name="productBusinessService")
	public ProductBusinessInterface getProductBusiness()
	{
		return new ProductBusinessService();
	}
	
	@Bean(name="registrationService")
	public RegistrationServiceInterface getRegistrationService()
	{
		return new RegistrationService();
	}
}
