package com.gcu.business;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.gcu.data.ProductsDataService;
import com.gcu.data.entity.ProductEntity;
import com.gcu.model.ProductModel;

public class ProductBusinessService implements ProductBusinessInterface
{
	@Autowired
	public ProductsDataService service;
	
	@Override
	public List<ProductModel> getProducts()
	{
		// Get all the Entity Orders
		List<ProductEntity> productsEntity = service.findAll();
		
		// Iterate over the Entity Orders and create a List of Domain Orders
		List<ProductModel> productsDomain = new ArrayList<ProductModel>();
		for (ProductEntity entity : productsEntity)
		{
			productsDomain.add(new ProductModel(entity.getProductName(), entity.getDesc(),
					entity.getStock(), entity.getPrice()));
		}
		
		
		
		// Return list of Domain Orders
		return productsDomain;
	}
}
