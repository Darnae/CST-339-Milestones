package com.gcu.business;

import java.util.List;

import com.gcu.model.ProductModel;

public interface ProductBusinessInterface 
{
	public List<ProductModel> getProducts();
}
