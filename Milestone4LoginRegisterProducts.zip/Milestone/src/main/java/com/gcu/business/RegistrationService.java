package com.gcu.business;

import com.gcu.User;

import jakarta.validation.Valid;

import org.springframework.stereotype.Service;

@Service
public class RegistrationService implements RegistrationServiceInterface {

    @Override
    public boolean register(@Valid User user) {
        // Simulate registration logic, e.g., validate fields or check for unique username
        System.out.println("Registering user: " + user.getUsername());
        return true; // Simulate successful registration
    }
}
