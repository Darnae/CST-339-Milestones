package com.gcu.business;

import com.gcu.User;

import jakarta.validation.Valid;

public interface RegistrationServiceInterface {
	boolean register(@Valid User user);
}
